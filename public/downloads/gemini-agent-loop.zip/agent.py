import os
import json
from google import genai
from google.genai import types
from pydantic import BaseModel, Field

# Ensure API key is configured
if "GEMINI_API_KEY" not in os.environ:
    print("WARNING: GEMINI_API_KEY environment variable not set.")
    print("Please set it: export GEMINI_API_KEY='your_key_here'\n")

# Initialize the Gemini GenAI client
# Using the modern GenAI SDK standards
client = genai.Client()

# ---------------------------------------------------------
# 1. Define Structured Output Schema
# ---------------------------------------------------------
class TaskAnalysis(BaseModel):
    task_name: str = Field(description="Name of the parsed task")
    complexity: str = Field(description="Complexity level: LOW, MEDIUM, or HIGH")
    estimated_hours: float = Field(description="Estimated time to complete in hours")
    required_skills: list[str] = Field(description="Skills required to complete this task")
    subtasks: list[str] = Field(description="List of step-by-step subtasks")

# ---------------------------------------------------------
# 2. Define Custom Tools (Function Calling)
# ---------------------------------------------------------
def get_web_page_status(url: str) -> str:
    """Check the online availability and server status of a specific URL.

    Args:
        url: The web URL to inspect (e.g. 'https://google.com')
    """
    # A real script would use requests.get, we mock it here for demonstration
    if "error" in url:
        return "HTTP 500: Internal Server Error"
    return "HTTP 200: OK (Service is active and online)"

# ---------------------------------------------------------
# 3. Main Agent Execution Function
# ---------------------------------------------------------
def run_diagnostic_agent(prompt_text: str):
    print("Initializing Agent Loop...")
    print(f"User Prompt: '{prompt_text}'\n")

    # Configure generation parameters
    # Binding the structured schema and custom tools
    config = types.GenerateContentConfig(
        response_mime_type="application/json",
        response_schema=TaskAnalysis,
        tools=[get_web_page_status],
        temperature=0.2,
    )

    try:
        response = client.models.generate_content(
            model="gemini-1.5-pro",
            contents=prompt_text,
            config=config,
        )

        # Print the raw validated JSON output
        print("--- AGENT RESPONSE (Validated JSON Schema) ---")
        print(response.text)
        
        # Verify the structure by loading it in Python
        data = json.loads(response.text)
        print("\nSuccessfully parsed JSON object keys:")
        for key, val in data.items():
            print(f" - {key}: {val}")

    except Exception as e:
        print(f"Error executing agent loop: {e}")

if __name__ == "__main__":
    # Test task prompt
    sample_prompt = (
        "Inspect the status of https://neutraloverdrive.com. "
        "Then, write a task plan to migrate the hosting provider to AWS. "
        "Provide estimated hours, required skills, and subtasks."
    )
    run_diagnostic_agent(sample_prompt)
