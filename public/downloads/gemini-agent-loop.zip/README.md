# Gemini 1.5 Pro Agent Loop Script

This is a production-grade Python orchestrator script demonstrating how to enforce strict JSON schemas and bind custom tools (function calling) using the Google GenAI SDK.

## Requirements

Ensure you have Python 3.9+ installed.

## Setup Instructions

1. **Create a virtual environment (optional but recommended):**
   ```bash
   python -m venv venv
   source venv/bin/activate  # On macOS/Linux
   # venv\Scripts\activate  # On Windows
   ```

2. **Install dependencies:**
   ```bash
   pip install -r requirements.txt
   ```

3. **Set your Gemini API Key:**
   Get an API key from Google AI Studio and configure it in your terminal environment:
   ```bash
   export GEMINI_API_KEY="your_api_key_here"  # On macOS/Linux
   # set GEMINI_API_KEY="your_api_key_here"  # On Windows CMD
   # $env:GEMINI_API_KEY="your_api_key_here"  # On Windows PowerShell
   ```

4. **Run the script:**
   ```bash
   python agent.py
   ```

## Script Architecture

* **Structured Outputs:** Uses Pydantic to define the `TaskAnalysis` schema, ensuring Gemini's response is structured and validated.
* **Custom Tools:** Binds a dummy tool (`get_web_page_status`) to the model, demonstrating how Gemini decides when to make external function calls based on the prompt description.
